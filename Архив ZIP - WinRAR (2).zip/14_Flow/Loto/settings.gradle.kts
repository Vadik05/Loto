
rootProject.name = "Loto"

