import kotlinx.coroutines.launch
import kotlinx.coroutines.*
import kotlinx.coroutines.flow.MutableSharedFlow
import kotlinx.coroutines.flow.asSharedFlow
import java.util.Collections.shuffle


suspend fun main() {
    val player1 = Player()
    player1.getCard()



            var counter = 0
            var coin = 0
            Generator.sharedFlow.collect{

                println("Ход ${counter + 1}. Выпал номер $it")
                counter ++
                for (row in player1.card) {
                    for (it in row){
                        if (it in row){
                            println("sovpalo")
                            coin++
                        }
                    }

                }

            }


}






object Generator {
        private val scope = CoroutineScope(Job() + Dispatchers.Default)
        private val sharedFlowOne = MutableSharedFlow<Int>()
        val sharedFlow = sharedFlowOne.asSharedFlow()

        init {
            scope.launch {
                val barrel: MutableList<Int> = (1..90).toMutableList()
                shuffle(barrel)
                for (it in 0 until barrel.size) {
                    sharedFlowOne.emit(barrel[it])
                    delay(1000)
                }
                scope.cancel()
            }
        }
    }


